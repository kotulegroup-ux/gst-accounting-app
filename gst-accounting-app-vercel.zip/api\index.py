import os
import sys
from pathlib import Path

# Add project root to sys.path so 'app' package can be imported on Vercel
ROOT_DIR = Path(__file__).resolve().parent.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

# Ensure database tables exist before handling requests
try:
    from app.database import ensure_db_ready
    ensure_db_ready()
except Exception as e:
    print(f"Startup DB init warning: {e}")

from app.main import app
