"""
Main FastAPI Application Entrypoint.
"""
import traceback
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse, HTMLResponse
from starlette.middleware.sessions import SessionMiddleware

from app.config import SECRET_KEY, APP_TITLE
from app.database import init_db, ensure_db_ready
from app.routers import (
    auth_router,
    client_router,
    sales_router,
    purchase_router,
    payment_router,
    party_router,
    report_router,
    admin_router
)

app = FastAPI(title=APP_TITLE, version="1.0.0")

# Session Middleware for cookie sessions
app.add_middleware(
    SessionMiddleware,
    secret_key=SECRET_KEY,
    max_age=86400 * 30, # 30 days session
    same_site="lax"
)

# Static Files Mount (Safely mounted only if exists)
static_dir = Path(__file__).resolve().parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

# Health check / ping endpoint
@app.get("/ping")
def ping():
    return {"status": "ok", "app": APP_TITLE}

# Include Routers
app.include_router(auth_router.router)
app.include_router(client_router.router)
app.include_router(sales_router.router)
app.include_router(purchase_router.router)
app.include_router(payment_router.router)
app.include_router(party_router.router)
app.include_router(report_router.router)
app.include_router(admin_router.router)

@app.on_event("startup")
def on_startup():
    ensure_db_ready()

# Also run ensure_db_ready at import time for serverless runtimes
try:
    ensure_db_ready()
except Exception as e:
    print(f"Serverless init DB error: {e}")

@app.exception_handler(404)
async def custom_404_handler(request: Request, exc):
    if request.url.path not in ("/", "/login") and not request.url.path.startswith(("/static", "/api", "/ping")):
        return RedirectResponse("/", status_code=302)
    return HTMLResponse("<h3>404 Not Found</h3><p><a href='/login'>Go to Login</a></p>", status_code=404)

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    tb = traceback.format_exc()
    print("CRITICAL SERVER ERROR:", tb)
    return HTMLResponse(
        status_code=500,
        content=f"""
        <div style="font-family: sans-serif; padding: 30px; max-width: 800px; margin: 40px auto; border: 1px solid #f87171; border-radius: 12px; background: #fef2f2;">
            <h2 style="color: #991b1b; margin-top: 0;">Server Error (500)</h2>
            <p><strong>Path:</strong> {request.url.path}</p>
            <p><strong>Exception:</strong> {str(exc)}</p>
            <pre style="background: #fee2e2; padding: 15px; border-radius: 8px; overflow: auto; font-size: 13px; color: #7f1d1d;">{tb}</pre>
        </div>
        """
    )
